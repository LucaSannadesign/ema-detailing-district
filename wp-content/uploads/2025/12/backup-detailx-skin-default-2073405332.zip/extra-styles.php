<?php
// Add plugin-specific colors and fonts to the custom CSS
if ( ! function_exists( 'detailx_extra_styles_get_css' ) ) {
	add_filter( 'detailx_filter_get_css', 'detailx_extra_styles_get_css', 10, 2 );
	function detailx_extra_styles_get_css( $css, $args ) {
		if ( isset( $css['fonts'] ) && isset( $args['fonts'] ) ) {
			$fonts         = $args['fonts'];
			$css['fonts'] .= <<<CSS
	
.sc_blogger .sc_blogger_filters .sc_item_filters_tabs li a {
	{$fonts['h6_font-family']}
	{$fonts['h6_font-weight']}
	{$fonts['h6_text-transform']}
}

.sc_socials .social_item.social_item_type_names .social_name {
	{$fonts['p_font-family']}
}



CSS;
		}
		
		return $css;
	}
}

