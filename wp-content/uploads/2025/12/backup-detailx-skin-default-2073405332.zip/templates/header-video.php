<?php
/**
 * The template to display the background video in the header
 *
 * @package DETAILX
 * @since DETAILX 1.0.14
 */
$detailx_header_video = detailx_get_header_video();
$detailx_embed_video  = '';
if ( ! empty( $detailx_header_video ) && ! detailx_is_from_uploads( $detailx_header_video ) ) {
	if ( detailx_is_youtube_url( $detailx_header_video ) && preg_match( '/[=\/]([^=\/]*)$/', $detailx_header_video, $matches ) && ! empty( $matches[1] ) ) {
		?><div id="background_video" data-youtube-code="<?php echo esc_attr( $matches[1] ); ?>"></div>
		<?php
	} else {
		?>
		<div id="background_video"><?php detailx_show_layout( detailx_get_embed_video( $detailx_header_video ) ); ?></div>
		<?php
	}
}
