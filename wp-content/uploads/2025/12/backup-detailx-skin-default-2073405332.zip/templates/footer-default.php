<?php
/**
 * The template to display default site footer
 *
 * @package DETAILX
 * @since DETAILX 1.0.10
 */

?>
<footer class="footer_wrap footer_default
<?php
$detailx_footer_scheme = detailx_get_theme_option( 'footer_scheme' );
if ( ! empty( $detailx_footer_scheme ) && ! detailx_is_inherit( $detailx_footer_scheme  ) ) {
	echo ' scheme_' . esc_attr( $detailx_footer_scheme );
}
?>
				">
	<?php

	// Footer widgets area
	get_template_part( apply_filters( 'detailx_filter_get_template_part', 'templates/footer-widgets' ) );

	// Logo
	get_template_part( apply_filters( 'detailx_filter_get_template_part', 'templates/footer-logo' ) );

	// Socials
	get_template_part( apply_filters( 'detailx_filter_get_template_part', 'templates/footer-socials' ) );

	// Copyright area
	get_template_part( apply_filters( 'detailx_filter_get_template_part', 'templates/footer-copyright' ) );

	?>
</footer><!-- /.footer_wrap -->
