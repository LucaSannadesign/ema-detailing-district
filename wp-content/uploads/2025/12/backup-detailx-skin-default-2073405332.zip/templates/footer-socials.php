<?php
/**
 * The template to display the socials in the footer
 *
 * @package DETAILX
 * @since DETAILX 1.0.10
 */


// Socials
if ( detailx_is_on( detailx_get_theme_option( 'socials_in_footer' ) ) ) {
	$detailx_output = detailx_get_socials_links();
	if ( '' != $detailx_output ) {
		?>
		<div class="footer_socials_wrap socials_wrap">
			<div class="footer_socials_inner">
				<?php detailx_show_layout( $detailx_output ); ?>
			</div>
		</div>
		<?php
	}
}
